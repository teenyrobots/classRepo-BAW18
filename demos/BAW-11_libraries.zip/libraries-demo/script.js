/* scripts for libraries demo */

$(document).ready(function(){

	$('.myGallery a').simpleLightbox();
	
})